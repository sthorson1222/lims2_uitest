package clerk.steps;

import clerk.runner.SetUp;
import com.microsoft.playwright.Page;
import com.microsoft.playwright.options.AriaRole;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.When;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;


import static org.junit.jupiter.api.Assertions.assertTrue;

public class BriefsSteps {

    private static final Logger logger = LoggerFactory.getLogger(BriefsSteps.class);
    private final Page page;

    public BriefsSteps() {
        // Ensure Playwright page is initialized
        if (SetUp.getPage() == null) {
            try {
                SetUp.setUp();
            } catch (InterruptedException e) {
                logger.error("Error during Playwright setup", e);
                Thread.currentThread().interrupt(); // Restore interrupt status
                throw new RuntimeException("Failed to initialize Playwright", e);
            }
        }

        this.page = SetUp.getPage();
        logger.info("BriefsSteps instance created and Playwright page is ready.");
    }





    @Given("user successfully login")
    public void userSuccessfullyLogin() {
        logger.info("Attempting to login...");
        page.getByRole(AriaRole.LINK, new Page.GetByRoleOptions().setName("Legislative Information")).click();
        assertTrue(page.locator("text=LIMS Modules").isVisible());
        logger.info("User logged in successfully and 'LIMS Modules' is visible.");
    }


    @When("the user selects {string}")
    public void selectLink(String linkName) {
        logger.info("Selecting link: {}", linkName);
        try {
            page.getByRole(AriaRole.LINK, new Page.GetByRoleOptions().setName(linkName)).click();
            logger.info("Successfully clicked link: {}", linkName);
        } catch (Exception e) {
            logger.info("Error selecting link: {}", linkName, e);
            throw e;
        }
    }


}