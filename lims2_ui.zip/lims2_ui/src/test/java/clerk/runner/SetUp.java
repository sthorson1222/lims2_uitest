package clerk.runner;

import clerk.utils.EnvConfig;
import clerk.utils.LoginManager;
import com.microsoft.playwright.*;
import io.cucumber.java.AfterAll;
import io.cucumber.java.BeforeAll;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;



public class SetUp {

    private static final Logger logger = LoggerFactory.getLogger(SetUp.class);
    private static final Path EXCEL_OUTPUT_PATH = Paths.get("CommitteeActions.xlsx");

    public static Playwright playwright;
    public static Browser browser;
    public static Page page;
    private static final List<String[]> billData = new ArrayList<>();

    @BeforeAll
    public static void setUp() throws InterruptedException {
        logger.info("🔧 Initializing Playwright...");
        playwright = Playwright.create();
        browser = playwright.chromium().launch(new BrowserType.LaunchOptions().setHeadless(false));

        BrowserContext context = browser.newContext(new Browser.NewContextOptions().setViewportSize(null));
        page = context.newPage();

        addNetworkListeners(context);
        logger.info("🌐 Starting session...");

        Thread.sleep(2000);
        String username = EnvConfig.getString("USERNAME");
        String password = EnvConfig.getString("PASSWORD");
        String baseUrl = EnvConfig.getString("BASE_URL");

        LoginManager.login(page, baseUrl, username, password);


        logger.info("✅ Setup complete.");
    }

    private static void addNetworkListeners(BrowserContext context) {
        context.onRequest(request -> logger.debug("📤 Request: {} {}", request.method(), request.url()));
        context.onRequestFailed(request -> logger.error("❌ Request failed: {} [{}]", request.url(), request.failure()));
        context.onResponse(response -> {
            if (response.status() >= 400) {
                logger.warn("⚠️ Response error: {} [{}]", response.url(), response.status());
            }
        });
        context.onRequestFinished(request -> logger.debug("✅ Request finished: {}", request.url()));
    }

    public static Page getPage() {
        if (page == null) {
            logger.error("❌ Page is not initialized. Call setUp() first.");
            throw new IllegalStateException("Page is not initialized.");
        }
        return page;
    }

    public static void collectBillData(String billNumber, String committeeAction, String validationStatus) {
        logger.debug("📋 Data: {} | {} | {}", billNumber, committeeAction, validationStatus);
        billData.add(new String[]{billNumber, committeeAction, validationStatus});
    }

    @AfterAll
    public static void exportTestResults() {
        logger.info("📤 Exporting test results...");
        exportBillDataToExcel();
       // ExcelExporterUtil.exportTransactionNumbersToExcel();
        logger.info("✅ Data export finished.");
    }

    private static void exportBillDataToExcel() {
        if (billData.isEmpty()) {
            logger.info("ℹ️ No data to export.");
            return;
        }

        try (Workbook workbook = new XSSFWorkbook()) {
            Sheet sheet = workbook.createSheet("Committee Actions");
            createHeaderRow(sheet, workbook);

            for (int i = 0; i < billData.size(); i++) {
                Row row = sheet.createRow(i + 1);
                for (int j = 0; j < billData.get(i).length; j++) {
                    row.createCell(j).setCellValue(billData.get(i)[j]);
                }
            }

            try (FileOutputStream fileOut = new FileOutputStream(EXCEL_OUTPUT_PATH.toFile())) {
                workbook.write(fileOut);
                logger.info("✅ Excel written: {}", EXCEL_OUTPUT_PATH.toAbsolutePath());
            }

        } catch (IOException e) {
            logger.error("❌ Excel export failed: {}", e.getMessage(), e);
            throw new RuntimeException("Excel export failed", e);
        }
    }

    private static void createHeaderRow(Sheet sheet, Workbook workbook) {
        Row headerRow = sheet.createRow(0);
        String[] headers = {"Bill Number", "Committee Action", "Validation Status"};

        CellStyle headerStyle = workbook.createCellStyle();
        Font font = workbook.createFont();
        font.setBold(true);
        headerStyle.setFont(font);

        for (int i = 0; i < headers.length; i++) {
            Cell cell = headerRow.createCell(i);
            cell.setCellValue(headers[i]);
            cell.setCellStyle(headerStyle);
        }
    }
}
