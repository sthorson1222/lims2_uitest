package clerk.utils;

import com.microsoft.playwright.Locator;
import com.microsoft.playwright.Page;


public enum CommitteeActions {

    SUBCOMMITTEE_REFERRAL("Subcommittee Referral", "[data-testid='committeeAction_Committee_Subcommittee Referral']"),
    EXECUTIVE_COMMENT_REQUESTED("Executive Comment Requested", "[data-testid='committeeAction_Committee_Executive Comment Requested']"),
    EXECUTIVE_COMMENT_RECEIVED("Executive Comment Received", "[data-testid='committeeAction_Committee_Executive Comment Received']"),
    REPORT_MEASURE_DEFEATED("Report Measure Defeated", "[data-testid='committeeAction_Committee_Report Measure Defeated']"),
    REPORTED_IN_LIEU("Reported in Lieu", "[data-testid='committeeAction_Committee_Reported in Lieu']"),
    CONSIDERATION_AND_MARKUP("Consideration and Markup", "[data-testid='committeeAction_Committee_Consideration and Markup']"),
    FURTHER_AMENDMENTS_APPROVED("Further Amendments Approved", "[data-testid='committeeAction_Committee_Further Amendments Approved']"),
    ORDERED_TO_BE_REPORTED("Ordered to be Reported", "[data-testid='committeeAction_Committee_Ordered to be Reported']"),
    HEARINGS_HELD("Hearings Held", "[data-testid='committeeAction_Committee_Hearings Held']"),
    CROSS_REFERENCED_BILLS("Cross-Referenced Bills (See Bill)", "[data-testid='committeeAction_Committee_Cross-Referenced Bills (See Bill)']"),
    AGREED_TO_SEEK_CONSIDERATION("Agreed to Seek Consideration Under Suspension", "[data-testid='committeeAction_Committee_Agreed to Seek Consideration Under Suspension']"),
    SUBCOMMITTEE_DISCHARGED("Subcommittee Discharged", "[data-testid='committeeAction_Committee_Subcommittee Discharged']");

    private final String action;
    private final String selector;

    CommitteeActions(String action, String selector) {
        this.action = action;
        this.selector = selector;
    }

    public String getAction() {
        return action;
    }

    public Locator getLocator(Page page) {
        return page.locator(selector);
    }

    public static Locator getByActionName(Page page, String actionName) {
        for (CommitteeActions action : values()) {
            if (action.getAction().equalsIgnoreCase(actionName)) {
                return action.getLocator(page);
            }
        }
        throw new IllegalArgumentException("Invalid Committee Action: " + actionName);
    }
}
