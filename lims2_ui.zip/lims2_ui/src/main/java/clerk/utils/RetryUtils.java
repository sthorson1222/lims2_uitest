package clerk.utils;

import com.microsoft.playwright.Page;
import com.microsoft.playwright.Page.ScreenshotOptions;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.logging.Logger;

public class RetryUtils {

    private static final Logger logger = Logger.getLogger(RetryUtils.class.getName());
    private static final String OUTPUT_DIR = "screenshots/";
    private static final int RETRY_DELAY_MS = 1500;
    private static final DateTimeFormatter TIMESTAMP_FORMAT = DateTimeFormatter.ofPattern("yyyyMMdd_HHmmss");

//
public static void retryWithScreenshotAndDomCapture(Runnable logic, String stepName, Page page, int maxRetries, Healer healer) {
    for (int attempt = 1; attempt <= maxRetries; attempt++) {
        try {
            logic.run();
            return; // ✅ success
        } catch (Exception e) {
            String timestamp = LocalDateTime.now().format(TIMESTAMP_FORMAT);
            logger.warning(String.format("⚠️ Attempt %d/%d failed for step '%s': %s", attempt, maxRetries, stepName, e.getMessage()));

            try {
                // Ensure output directory exists
                Files.createDirectories(Paths.get(OUTPUT_DIR));

                // Screenshot
                String screenshotPath = OUTPUT_DIR + stepName + "_attempt" + attempt + "_" + timestamp + ".png";
                page.screenshot(new ScreenshotOptions().setPath(Paths.get(screenshotPath)).setFullPage(true));
                logger.warning("📸 Screenshot saved: " + screenshotPath);

                // DOM snapshot
                String domPath = OUTPUT_DIR + stepName + "_attempt" + attempt + "_" + timestamp + ".html";
                String html = page.content();
                Files.writeString(Paths.get(domPath), html);
                logger.warning("📄 DOM snapshot saved: " + domPath);

                // Healing attempt (if supplied)
                if (healer != null) {
                    logger.info("🩺 Invoking healing mechanism...");
                    healer.heal(page, stepName, attempt);
                }

            } catch (IOException ioEx) {
                logger.severe("❌ Failed to capture debug info: " + ioEx.getMessage());
            }

            if (attempt < maxRetries) {
                try {
                    Thread.sleep(RETRY_DELAY_MS);
                } catch (InterruptedException ie) {
                    Thread.currentThread().interrupt();
                    logger.warning("⏸️ Retry sleep interrupted");
                }
            } else {
                throw new RuntimeException(
                        String.format("❌ Step '%s' failed after %d attempts", stepName, maxRetries), e);
            }
        }
    }
}

}
