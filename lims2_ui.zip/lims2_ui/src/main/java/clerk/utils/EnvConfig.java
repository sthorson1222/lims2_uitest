package clerk.utils;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

public class EnvConfig {



    private static final Map<String, String> envVars = new HashMap<>();

    static {
        loadEnvVariables();
    }

    // Method to load .env file
    private static void loadEnvVariables() {
        String envFilePath = ".env";  // Path to your .env file

        try (BufferedReader reader = new BufferedReader(new FileReader(envFilePath))) {
            String line;
            while ((line = reader.readLine()) != null) {
                line = line.trim();

                // Skip empty lines and comments
                if (line.isEmpty() || line.startsWith("#")) {
                    continue;
                }

                String[] keyValue = line.split("=", 2);
                if (keyValue.length == 2) {
                    envVars.put(keyValue[0].trim(), keyValue[1].trim());
                }
            }
        } catch (IOException e) {
            System.err.println("Error reading .env file: " + e.getMessage());
        }
    }

    // Method to get string value
    public static String getString(String key) {
        return envVars.get(key);
    }

    // Method to get integer value
    public static int getInt(String key) {
        return Integer.parseInt(envVars.get(key));
    }

    // Method to get boolean value
    public static boolean getBoolean(String key) {
        return Boolean.parseBoolean(envVars.get(key));
    }
}

