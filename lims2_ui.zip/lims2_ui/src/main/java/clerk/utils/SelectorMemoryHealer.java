package clerk.utils;

import com.microsoft.playwright.Locator;
import com.microsoft.playwright.Page;

import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.logging.Logger;

/**
 * Healer implementation that attempts fallback selectors dynamically or from memory
 * when a known element interaction fails during retries.
 */
public class SelectorMemoryHealer implements Healer {
    private static final Logger logger = Logger.getLogger(SelectorMemoryHealer.class.getName());

    // Static fallback selector memory (can be enhanced to load from config later)
    private final Map<String, List<String>> staticFallbacks = new HashMap<>();

    public SelectorMemoryHealer() {
        // Register static fallbacks for specific steps
        staticFallbacks.put("SubmitForm", List.of(".btn-primary", "button[type='submit']"));
        staticFallbacks.put("LoginButton", List.of("#loginBtnAlt", ".auth-button", "text='Log In'"));
    }

    @Override
    public void heal(Page page, String stepName, int attempt) {
        List<String> fallbackSelectors = getFallbackSelectors(stepName);

        if (fallbackSelectors.isEmpty()) {
            logger.warning("🛠️ No fallback selectors found for step: " + stepName);
            return;
        }

        logger.info(String.format("🩹 Healing '%s' [attempt %d] using %d fallback selector(s)...",
                stepName, attempt, fallbackSelectors.size()));

        for (String selector : fallbackSelectors) {
            try {
                Locator locator = page.locator(selector);
                if (locator.isVisible()) {
                    logger.info("✅ Healing succeeded using selector: " + selector);
                    locator.click(); // Or interact appropriately
                    return;
                } else {
                    logger.info("⛔ Selector not visible: " + selector);
                }
            } catch (Exception ex) {
                logger.warning("⚠️ Failed healing with selector '" + selector + "': " + ex.getMessage());
            }
        }

        logger.severe("💀 Healing failed: No fallback selector worked for step: " + stepName);
    }

    private List<String> getFallbackSelectors(String stepName) {
        // 1. Exact match from static map
        if (staticFallbacks.containsKey(stepName)) {
            return staticFallbacks.get(stepName);
        }

        // 2. Dynamic fallback for transaction validation steps
        if (stepName.startsWith("validate_txn_display_")) {
            String txnNumber = stepName.substring("validate_txn_display_".length());
            return List.of(
                    "div.pill-bubble:has-text('" + txnNumber + "')",
                    "div[data-testid='txn-pill']",
                    "span.tag:has-text('" + txnNumber + "')"
            );
        }

        // 3. Default: empty list
        return Collections.emptyList();
    }
}
