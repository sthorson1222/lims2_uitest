package clerk.utils;


import java.util.List;

public class BillModel {


    public String billNumber;
    public String transactionNumber;
    public List<String> expectedCosponsors;
    public List<String> expectedReferrals;
}
