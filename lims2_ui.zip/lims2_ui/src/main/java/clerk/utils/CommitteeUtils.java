package clerk.utils;



import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Random;

public class CommitteeUtils {

    public static List<Committee> getRandomCommittees(int n) {
        List<Committee> all = new ArrayList<>(List.of(Committee.values()));
        Collections.shuffle(all);
        return all.subList(0, Math.min(n, all.size()));
    }

    public static List<Committee> getRandomCommitteesBetween(int min, int max) {
        int n = new Random().nextInt(max - min + 1) + min;
        return getRandomCommittees(n);
    }
}

