package clerk.utils;

public enum Committee {
    AGRICULTURE("Agriculture"),
    APPROPRIATIONS("Appropriations"),
    ARMED_SERVICES("Armed Services"),
    BUDGET("Budget"),
    EDUCATION_AND_WORKFORCE("Education and Workforce"),
    ENERGY_AND_COMMERCE("Energy and Commerce"),
    ETHICS("Ethics"),
    FINANCIAL_SERVICES("Financial Services"),
    FOREIGN_AFFAIRS("Foreign Affairs"),
    HOMELAND_SECURITY("Homeland Security"),
    HOUSE_ADMINISTRATION("House Administration"),
    INTELLIGENCE("Intelligence"),
    JUDICIARY("Judiciary"),
    NATURAL_RESOURCES("Natural Resources"),
    OVERSIGHT_AND_REFORM("Oversight and Government Reform"),
    RULES("Rules"),
    SCIENCE_SPACE_TECH("Science, Space, and Technology"),
    SMALL_BUSINESS("Small Business"),
    TRANSPORTATION_INFRASTRUCTURE("Transportation and Infrastructure"),
    VETERANS_AFFAIRS("Veterans' Affairs"),
    WAYS_AND_MEANS("Ways and Means");

    private final String displayName;

    Committee(String displayName) {
        this.displayName = displayName;
    }

    public String getDisplayName() {
        return displayName;
    }
}