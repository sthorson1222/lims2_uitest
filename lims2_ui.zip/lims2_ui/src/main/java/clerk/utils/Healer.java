package clerk.utils;

import com.microsoft.playwright.Page;

/**
 * Functional interface for healing logic to be executed during retry attempts.
 * Implementations can attempt alternative selectors or recovery strategies
 * based on the step name, page state, or failure context.
 */
@FunctionalInterface
public interface Healer {
    /**
     * Executes healing logic for a failed test step.
     *
     * @param page     The current Playwright page instance
     * @param stepName The name of the failing test step
     * @param attempt  The retry attempt number (starting from 1)
     */
    void heal(Page page, String stepName, int attempt);
}
