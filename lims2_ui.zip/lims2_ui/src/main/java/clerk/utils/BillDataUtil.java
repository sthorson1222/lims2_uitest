package clerk.utils;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;
import com.microsoft.playwright.Page;

import java.io.IOException;
import java.io.Reader;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;
import java.util.*;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.stream.Collectors;

public class BillDataUtil {
    private static final Logger logger = Logger.getLogger(BillDataUtil.class.getName());
    private static final String FILE_PATH = "dom/introduced_bills.json";
    private static final Gson gson = new GsonBuilder().setPrettyPrinting().create();

    /** Scrapes all introduced bill brief rows from the current Playwright page */
    public static void scrapeFromBriefs(Page page) {
        try {
            waitForTableLoad(page);
           // adjustPaginationIfNeeded(page);

            List<Map<String, Object>> records = extractBriefData(page);
            saveRecordsToFile(records, FILE_PATH); // <- pass FILE_PATH explicitly


            logger.info("✅ Introduced bills saved to " + FILE_PATH);
        } catch (Exception e) {
            logger.log(Level.SEVERE, "❌ Error scraping bills", e);
        }
    }

    private static void waitForTableLoad(Page page) {
        page.waitForSelector("td[data-label='Original File Name']", new Page.WaitForSelectorOptions().setTimeout(10000));
        page.waitForTimeout(1000);
    }

//    private static void adjustPaginationIfNeeded(Page page) {
//        Locator paginationLabel = page.locator("div.MuiTablePagination-displayedRows");
//        paginationLabel.waitFor(new Locator.WaitForOptions().setTimeout(5000));
//        String labelText = paginationLabel.innerText();
//        int totalCount = Integer.parseInt(labelText.split("of")[1].trim());
//
//        if (totalCount > 200) {
//            Locator dropdown = page.locator("select.MuiNativeSelect-select");
//            dropdown.waitFor(new Locator.WaitForOptions().setTimeout(3000));
//            dropdown.selectOption("500");
//            page.waitForTimeout(2000);
//            logger.info("🔁 Set rows per page to 500. Total rows: " + totalCount);
//        }
//    }

    private static List<Map<String, Object>> extractBriefData(Page page) {
        List<String> transactionNumbers = page.locator("td[data-label='Transaction Number']").allInnerTexts();
        List<String> fileNames = page.locator("td[data-label='Original File Name']").allInnerTexts();
        List<String> sponsors = page.locator("td[data-label='Sponsor']").allInnerTexts();
        List<String> billNumbers = page.locator("td[data-label='Bill Type/Number']").allInnerTexts();
        List<String> limsStatus = page.locator("td[data-label='LIMS Status']").allInnerTexts();
        List<String> calendarDates = page.locator("td[data-label='Calendar Date']").allInnerTexts();
        List<String> legislativeDays = page.locator("td[data-label='Legislative Day']").allInnerTexts();
        List<String> actions = page.locator("td[data-label='Action']").allInnerTexts();
        List<String> billClasses = page.locator("td[data-label='Bill Class']").allInnerTexts();
        List<String> referrals = page.locator("td[data-label='Referrals List']").allInnerTexts();
        List<String> cosponsors = page.locator("td[data-label='Original Cosponsors']").allInnerTexts();

        List<Map<String, Object>> records = new ArrayList<>();

        for (int i = 0; i < fileNames.size(); i++) {
            Map<String, Object> row = new HashMap<>();
            row.put("transactionNumber", safeGet(transactionNumbers, i));
            row.put("originalFileName", safeGet(fileNames, i));
            row.put("sponsor", safeGet(sponsors, i));
            row.put("billNumber", safeGet(billNumbers, i));
            row.put("limsStatus", safeGet(limsStatus, i));
            row.put("calendarDate", safeGet(calendarDates, i));
            row.put("legislativeDay", safeGet(legislativeDays, i));
            row.put("action", safeGet(actions, i));
            row.put("billClass", safeGet(billClasses, i));
            row.put("originalCosponsors", safeGet(cosponsors, i));

            String referralsRaw = safeGet(referrals, i);
            List<String> referralList = Arrays.stream(referralsRaw.split("\\n"))
                    .map(String::trim)
                    .filter(s -> !s.isEmpty())
                    .distinct()
                    .collect(Collectors.toList());

            row.put("referrals", referralList);
            row.put("referralCount", String.valueOf(referralList.size()));
            records.add(row);
        }

        return records;
    }


    private static void saveRecordsToFile(List<Map<String, Object>> records, String filePath) throws IOException {
        if (records == null || records.isEmpty()) {
            logger.warning("⚠️ No records provided — skipping file write.");
            return;
        }

        Path path = Paths.get(filePath).toAbsolutePath();
        Path parentDir = path.getParent();

        if (parentDir != null && !Files.exists(parentDir)) {
            try {
                Files.createDirectories(parentDir);
                logger.info("📁 Created directory: " + parentDir);
            } catch (IOException e) {
                logger.severe("❌ Failed to create directory: " + parentDir + " — " + e.getMessage());
                throw e;
            }
        }

        try {
            Gson gson = new GsonBuilder().setPrettyPrinting().create();
            Files.writeString(path, gson.toJson(records), StandardOpenOption.CREATE, StandardOpenOption.TRUNCATE_EXISTING);
            logger.info("✅ File written to: " + path);
        } catch (IOException e) {
            logger.log(Level.SEVERE, "❌ Failed to write JSON file to: " + path, e);
            throw e;
        }
    }



    public static String safeGet(List<String> list, int index) {
        return (index >= 0 && index < list.size()) ? list.get(index).trim() : "";
    }

    /** Checks if all expected columns are visible in the table header */
    public static boolean areAllColumnsVisible(Page page, List<String> expectedColumns) {
        // Retrieve all the column headers from the table (with data-label attribute)
        List<String> actualHeaders = page.locator("th[data-label]").allInnerTexts();

        // Log the actual column headers found in the table
        logger.info("Actual columns found in the table: {}");

        // Normalize the column headers (trim and convert to lowercase for comparison)
        Set<String> visibleSet = new HashSet<>(actualHeaders.stream()
                .map(String::trim)               // Trim whitespace
                .map(String::toLowerCase)        // Convert to lowercase for case-insensitive comparison
                .toList());

        // Log the normalized (visible) column set
        logger.info("Normalized visible columns (lowercase, trimmed): {}");

        // Log the expected columns
        logger.info("Expected columns to be visible: {}");

        // Check if all expected columns are present in the visible set
        boolean result = expectedColumns.stream()
                .map(String::toLowerCase)         // Convert expected columns to lowercase
                .allMatch(visibleSet::contains);  // Check if all expected columns are in the visible set

        // Log whether the test passed or failed
        if (result) {
            logger.info("✅ All expected columns are visible in the table.");
        } else {
            logger.info("❌ Some expected columns are missing!");
        }

        return result;
    }


    /** Loads bill records from JSON as String maps (for flat display usage) */
    public static List<Map<String, String>> loadBills() {
        Path path = Paths.get(FILE_PATH);
        if (!Files.exists(path)) {
            logger.warning("⚠️ File not found: " + FILE_PATH);
            return Collections.emptyList();
        }

        try (Reader reader = Files.newBufferedReader(path)) {
            return gson.fromJson(reader, new TypeToken<List<Map<String, String>>>() {}.getType());
        } catch (IOException e) {
            logger.log(Level.SEVERE, "❌ Failed to read bill data", e);
            return Collections.emptyList();
        }
    }

    /** Loads bill records from JSON with mixed object types (for internal validations) */
    public static List<Map<String, Object>> loadBillsRaw() {
        Path path = Paths.get(FILE_PATH);
        if (!Files.exists(path)) {
            logger.warning("⚠️ File not found: " + FILE_PATH);
            return Collections.emptyList();
        }

        try (Reader reader = Files.newBufferedReader(path)) {
            return gson.fromJson(reader, new TypeToken<List<Map<String, Object>>>() {}.getType());
        } catch (IOException e) {
            logger.log(Level.SEVERE, "❌ Failed to read bill data", e);
            return Collections.emptyList();
        }
    }
}
