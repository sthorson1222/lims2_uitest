package clerk.utils;

import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.microsoft.playwright.BrowserContext;
import com.microsoft.playwright.Locator;
import com.microsoft.playwright.Page;
import com.microsoft.playwright.options.WaitForSelectorState;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Base64;

public class LoginManager {
    private static final Logger logger = LoggerFactory.getLogger(LoginManager.class);
    private static final Path SESSION_STORAGE_FILE = Paths.get("sessionStorage.json");

    public static void login(Page page, String baseUrl, String email, String password) {
        logger.info("🌐 Navigating to {}", baseUrl);
        page.navigate(baseUrl);
        page.waitForLoadState();

        try {
            Thread.sleep(2000); // Let initial UI stabilize
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }

        RetryUtils.retryWithScreenshotAndDomCapture(() -> {
            if (isTokenStillValid(page)) {
                logger.info("✅ Valid token found. Login skipped.");
                return;
            }

            logger.info("🔐 Token invalid or missing. Performing login...");
            performLogin(page, email, password);

            logger.info("💾 Saving sessionStorage after login...");
            saveSessionStorage(page);
        }, "login_flow", page, 3, new SelectorMemoryHealer());
    }

    private static void performLogin(Page page, String email, String password) {
        logger.info("🔐 Checking if login is required...");
        Locator loginButton = page.locator("//button[@data-testid='loginBtn']");
        if (!loginButton.isVisible()) {
            logger.info("ℹ️ No login required.");
            return;
        }

        loginButton.waitFor(new Locator.WaitForOptions().setState(WaitForSelectorState.VISIBLE).setTimeout(5000));
        loginButton.click();

        BrowserContext context = page.context();
        Page loginPage = (context.pages().size() > 1) ? context.pages().get(1) : page;

        Locator emailInput = loginPage.locator("input[name='loginfmt']");
        emailInput.waitFor(new Locator.WaitForOptions().setState(WaitForSelectorState.VISIBLE).setTimeout(5000));
        emailInput.fill(email);
        logger.debug("📧 Email entered.");

        Locator nextButton = loginPage.locator("//input[@type='submit']");
        nextButton.waitFor(new Locator.WaitForOptions().setState(WaitForSelectorState.VISIBLE).setTimeout(5000));
        nextButton.click();
        logger.debug("➡️ Next button clicked.");

        Locator activeDirectoryOption = loginPage.locator(".largeTextNoWrap.indentNonCollapsible:has-text('Active Directory')");
        activeDirectoryOption.waitFor(new Locator.WaitForOptions().setState(WaitForSelectorState.VISIBLE).setTimeout(3000));
        if (activeDirectoryOption.isVisible()) {
            activeDirectoryOption.click();
            logger.debug("🛂 Active Directory option clicked.");
        }

        Locator passwordInput = loginPage.locator("#passwordInput");
        passwordInput.waitFor(new Locator.WaitForOptions().setState(WaitForSelectorState.VISIBLE).setTimeout(5000));
        passwordInput.fill(password);
        logger.debug("🔑 Password entered.");

        Locator submitButton = loginPage.locator("#submitButton");
        submitButton.waitFor(new Locator.WaitForOptions().setState(WaitForSelectorState.VISIBLE).setTimeout(5000));
        submitButton.click();
        logger.debug("➡️ Submit button clicked.");

        Locator yesButton = loginPage.locator("input#idSIButton9[value='Yes']");
        yesButton.waitFor(new Locator.WaitForOptions().setState(WaitForSelectorState.VISIBLE).setTimeout(5000));
        yesButton.click();
        logger.info("✅ Login successful.");
    }

    private static void saveSessionStorage(Page page) {
        try {
            String json = page.evaluate("() => JSON.stringify(sessionStorage)").toString();
            Files.writeString(SESSION_STORAGE_FILE, json);
            logger.debug("📦 sessionStorage saved.");
        } catch (Exception e) {
            logger.error("❌ Failed to save sessionStorage: {}", e.getMessage(), e);
        }
    }

    private static boolean isTokenStillValid(Page page) {
        try {
            Object tokenObj = page.evaluate("() => sessionStorage.getItem('idToken')");
            if (tokenObj == null || tokenObj.toString().isEmpty()) {
                logger.info("🚫 idToken not found.");
                return false;
            }

            String token = tokenObj.toString();
            String[] parts = token.split("\\.");
            if (parts.length != 3) return false;

            String payloadJson = new String(Base64.getUrlDecoder().decode(parts[1]));
            JsonObject payload = JsonParser.parseString(payloadJson).getAsJsonObject();
            long exp = payload.get("exp").getAsLong();
            long now = System.currentTimeMillis() / 1000;

            if (exp < now) {
                logger.info("⏰ Token expired.");
                return false;
            }

            logger.info("🔐 Token valid. Expires at {} (unix)", exp);
            return true;

        } catch (Exception e) {
            logger.error("❌ Token validation failed: {}", e.getMessage(), e);
            return false;
        }
    }
}
